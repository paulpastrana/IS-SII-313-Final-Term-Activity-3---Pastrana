using System;
using System.Security.Cryptography;

namespace InventorySystem
{
    /// <summary>PBKDF2 (SHA-256) salted password hashing. Never store plain-text passwords.</summary>
    public static class PasswordHasher
    {
        private const int SaltSize = 16;
        private const int HashSize = 32;
        private const int Iterations = 100000;

        public static void Hash(string password, out string hash, out string salt)
        {
            byte[] saltBytes = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(saltBytes);

            byte[] hashBytes = Derive(password, saltBytes);
            hash = Convert.ToBase64String(hashBytes);
            salt = Convert.ToBase64String(saltBytes);
        }

        public static bool Verify(string password, string storedHash, string storedSalt)
        {
            byte[] expected = Convert.FromBase64String(storedHash);
            byte[] actual = Derive(password, Convert.FromBase64String(storedSalt));
            return ConstantTimeEquals(expected, actual);
        }

        private static byte[] Derive(string password, byte[] salt)
        {
            // The HashAlgorithmName overload is available from .NET Framework 4.7.2
            using (var kdf = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256))
                return kdf.GetBytes(HashSize);
        }

        // .NET Framework has no CryptographicOperations.FixedTimeEquals, so compare manually
        private static bool ConstantTimeEquals(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
