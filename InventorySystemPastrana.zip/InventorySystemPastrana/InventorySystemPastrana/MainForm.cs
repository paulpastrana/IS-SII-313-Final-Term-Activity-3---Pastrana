using System;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace InventorySystem
{
    public class MainForm : Form
    {
        public bool LoggedOut { get; private set; }

        // ---- palette ----
        private static readonly Color PageBack = Color.FromArgb(244, 246, 249);
        private static readonly Color Border = Color.FromArgb(222, 226, 232);
        private static readonly Color Ink = Color.FromArgb(31, 41, 55);
        private static readonly Color Muted = Color.FromArgb(107, 114, 128);
        private static readonly Color Accent = Color.FromArgb(37, 99, 235);
        private static readonly Color Red = Color.FromArgb(185, 28, 28);
        private static readonly Color Amber = Color.FromArgb(180, 83, 9);
        private static readonly Color Green = Color.FromArgb(21, 128, 61);
        private static readonly Color HeaderBg = Color.FromArgb(248, 249, 250);

        // ---- sample data: name, SKU, price, stock, minimum stock, pre-checked ----
        private static readonly object[][] Products =
        {
            new object[] { "HP EliteBook Laptop",      "EL-HP-022",   74999m, 14, 15, true  },
            new object[] { "Ergonomic Office Chair",   "CH-749-BLK",   4799m,  8,  5, false },
            new object[] { "Wireless Bluetooth Mouse", "CMGM-BT-255",   650m,  0, 20, false },
            new object[] { "External SSD 2TB",         "SD-EX-2TB",   15000m,  5,  5, true  },
            new object[] { "Mechanical Keyboard",      "KB-75",        2199m,  3, 10, false },
            new object[] { "23.8\" LCD Monitor",       "MN-LCD-238",   5499m, 18, 15, false },
        };

        private DataGridView grid;
        private CheckBox chkAll;
        private Panel selectionBar;
        private Label lblSelected;

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
        private const int EM_SETCUEBANNER = 0x1501;

        public MainForm(AppUser user)
        {
            Text = "IST IMS";
            ClientSize = new Size(1000, 680);
            MinimumSize = new Size(860, 600);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 10F);
            BackColor = PageBack;

            Panel header = BuildHeader(user);
            Panel cards = BuildCards();
            Panel toolbar = BuildToolbar();
            Panel gridHost = BuildGrid();
            BuildSelectionBar();

            // Docking order: the Fill control goes in first, then the Top panels
            // from the bottom-most to the top-most.
            Controls.Add(gridHost);
            Controls.Add(toolbar);
            Controls.Add(cards);
            Controls.Add(header);
            Controls.Add(selectionBar);
            selectionBar.BringToFront();

            Resize += (s, e) => PositionSelectionBar();
            Load += (s, e) => PositionSelectionBar();
            UpdateSelectionBar();
        }

        // ------------------------------------------------------------ header
        private Panel BuildHeader(AppUser user)
        {
            var header = new Panel { Dock = DockStyle.Top, Height = 96 };

            var lblTitle = new Label
            {
                Text = "Inventory",
                Font = new Font("Segoe UI", 22F, FontStyle.Bold),
                ForeColor = Ink,
                AutoSize = true,
                Location = new Point(24, 12)
            };
            var lblSub = new Label
            {
                Text = "Manage inventory, pricing and availability across your store.",
                ForeColor = Muted,
                AutoSize = true,
                Location = new Point(27, 60)
            };

            var btnAdd = new Button
            {
                Text = "+  Add Product",
                Size = new Size(150, 38),
                FlatStyle = FlatStyle.Flat,
                BackColor = Accent,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;

            string who = user.FullName + " (" + user.Role + ")   \u2022   Logout";
            var lnkLogout = new LinkLabel
            {
                Text = who,
                AutoSize = true,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Muted,
                LinkColor = Accent,
                ActiveLinkColor = Accent,
                LinkBehavior = LinkBehavior.HoverUnderline
            };
            lnkLogout.LinkArea = new LinkArea(who.Length - 6, 6);
            lnkLogout.LinkClicked += (s, e) => { LoggedOut = true; Close(); };

            header.Resize += (s, e) =>
            {
                btnAdd.Location = new Point(header.ClientSize.Width - btnAdd.Width - 24, 14);
                lnkLogout.Location = new Point(header.ClientSize.Width - lnkLogout.Width - 24, 60);
            };

            header.Controls.AddRange(new Control[] { lblTitle, lblSub, btnAdd, lnkLogout });
            return header;
        }

        // ------------------------------------------------------- stat cards
        private Panel BuildCards()
        {
            var host = new Panel { Dock = DockStyle.Top, Height = 140, Padding = new Padding(24, 4, 24, 12) };

            var table = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            Panel c1 = BuildCard("TOTAL PRODUCTS", "367", "-0.2%", false);
            c1.Margin = new Padding(0, 0, 12, 0);
            Panel c2 = BuildCard("TOTAL REVENUE", "\u20B1258,334", "+3.1%", true);
            c2.Margin = new Padding(12, 0, 0, 0);

            table.Controls.Add(c1, 0, 0);
            table.Controls.Add(c2, 1, 0);
            host.Controls.Add(table);
            return host;
        }

        private Panel BuildCard(string title, string value, string change, bool positive)
        {
            var card = new Panel { BackColor = Color.White, Dock = DockStyle.Fill };
            AddBorder(card);

            var lblTitle = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                ForeColor = Muted,
                AutoSize = true,
                Location = new Point(18, 14)
            };
            var lblValue = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 24F, FontStyle.Bold),
                ForeColor = Ink,
                AutoSize = true,
                Location = new Point(15, 38)
            };
            var lblChange = new Label
            {
                Text = change,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = positive ? Green : Red,
                AutoSize = true,
                Location = new Point(18, 94)
            };
            var lblPeriod = new Label
            {
                Text = "Last 7 days",
                Font = new Font("Segoe UI", 9F),
                ForeColor = Muted,
                AutoSize = true
            };
            var lblMenu = new Label
            {
                Text = "\u22EE",
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Muted,
                AutoSize = true
            };

            card.Resize += (s, e) =>
            {
                lblPeriod.Location = new Point(card.Width - lblPeriod.Width - 18, card.Height - lblPeriod.Height - 12);
                lblMenu.Location = new Point(card.Width - lblMenu.Width - 10, 8);
            };

            card.Controls.AddRange(new Control[] { lblTitle, lblValue, lblChange, lblPeriod, lblMenu });
            return card;
        }

        // ---------------------------------------------------------- toolbar
        private Panel BuildToolbar()
        {
            var toolbar = new Panel { Dock = DockStyle.Top, Height = 60 };

            var searchHost = new Panel
            {
                BackColor = Color.White,
                Size = new Size(320, 36),
                Location = new Point(24, 10)
            };
            AddBorder(searchHost);

            var lblIcon = new Label
            {
                Text = "\U0001F50D",
                Font = new Font("Segoe UI Emoji", 10F),
                ForeColor = Muted,
                AutoSize = true,
                Location = new Point(8, 6)
            };
            var txtSearch = new TextBox
            {
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 10.5F),
                Location = new Point(36, 8),
                Width = 270
            };
            txtSearch.HandleCreated += (s, e) =>
                SendMessage(txtSearch.Handle, EM_SETCUEBANNER, (IntPtr)1, "Search");

            searchHost.Controls.Add(lblIcon);
            searchHost.Controls.Add(txtSearch);

            var btnFilter = new Button
            {
                Text = "\u2261  Filter",
                Size = new Size(96, 36),
                Location = new Point(356, 10),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = Ink,
                Cursor = Cursors.Hand
            };
            btnFilter.FlatAppearance.BorderColor = Border;

            toolbar.Controls.Add(searchHost);
            toolbar.Controls.Add(btnFilter);
            return toolbar;
        }

        // --------------------------------------------------------- products grid
        private Panel BuildGrid()
        {
            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                AllowUserToResizeColumns = false,
                RowHeadersVisible = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None,
                EnableHeadersVisualStyles = false,
                GridColor = Color.FromArgb(235, 238, 242),
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 40,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            grid.RowTemplate.Height = 48;

            grid.ColumnHeadersDefaultCellStyle.BackColor = HeaderBg;
            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = HeaderBg;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Muted;
            grid.ColumnHeadersDefaultCellStyle.SelectionForeColor = Muted;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 0, 0);

            grid.DefaultCellStyle.BackColor = Color.White;
            grid.DefaultCellStyle.ForeColor = Ink;
            grid.DefaultCellStyle.SelectionBackColor = Color.White;
            grid.DefaultCellStyle.SelectionForeColor = Ink;
            grid.DefaultCellStyle.Padding = new Padding(8, 0, 0, 0);

            var colCheck = new DataGridViewCheckBoxColumn
            {
                HeaderText = "",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.None,
                Width = 44,
                Resizable = DataGridViewTriState.False,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            var colName = new DataGridViewTextBoxColumn
            {
                HeaderText = "Product Name",
                FillWeight = 36,
                ReadOnly = true,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            colName.DefaultCellStyle.Font = new Font("Segoe UI Semibold", 10F);
            var colSku = new DataGridViewTextBoxColumn
            {
                HeaderText = "SKU",
                FillWeight = 22,
                ReadOnly = true,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            colSku.DefaultCellStyle.Font = new Font("Consolas", 9.5F);
            colSku.DefaultCellStyle.ForeColor = Muted;
            var colPrice = new DataGridViewTextBoxColumn
            {
                HeaderText = "Price",
                FillWeight = 16,
                ReadOnly = true,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            var colStock = new DataGridViewTextBoxColumn
            {
                HeaderText = "Stock",
                FillWeight = 26,
                ReadOnly = true,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            grid.Columns.AddRange(new DataGridViewColumn[] { colCheck, colName, colSku, colPrice, colStock });

            foreach (object[] p in Products)
            {
                int stock = (int)p[3];
                int min = (int)p[4];
                string price = "\u20B1" + ((decimal)p[2]).ToString("N0", CultureInfo.InvariantCulture);
                string stockText = stock + " units   (min. " + min + " units)";

                int i = grid.Rows.Add((bool)p[5], (string)p[0], (string)p[1], price, stockText);

                // red = below minimum, amber = exactly at minimum
                Color c = stock < min ? Red : (stock == min ? Amber : Ink);
                grid.Rows[i].Cells[4].Style.ForeColor = c;
                grid.Rows[i].Cells[4].Style.SelectionForeColor = c;
            }
            grid.ClearSelection();

            // "select all" checkbox sitting in the header cell
            chkAll = new CheckBox
            {
                AutoSize = false,
                Size = new Size(18, 18),
                Location = new Point(13, 11),
                BackColor = HeaderBg
            };
            chkAll.CheckedChanged += (s, e) =>
            {
                foreach (DataGridViewRow row in grid.Rows)
                    row.Cells[0].Value = chkAll.Checked;
                UpdateSelectionBar();
            };
            grid.Controls.Add(chkAll);

            // tick/untick -> refresh highlight + "N selected" bar
            grid.CurrentCellDirtyStateChanged += (s, e) =>
            {
                if (grid.IsCurrentCellDirty)
                    grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            grid.CellValueChanged += (s, e) =>
            {
                if (e.ColumnIndex == 0 && e.RowIndex >= 0) UpdateSelectionBar();
            };

            var border = new Panel { Dock = DockStyle.Fill, Padding = new Padding(1), BackColor = Border };
            border.Controls.Add(grid);

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24, 0, 24, 24) };
            host.Controls.Add(border);
            return host;
        }

        // --------------------------------------------- floating "N selected" bar
        private void BuildSelectionBar()
        {
            selectionBar = new Panel
            {
                Size = new Size(314, 48),
                BackColor = Color.FromArgb(31, 41, 55)
            };

            lblSelected = new Label
            {
                ForeColor = Color.White,
                Font = new Font("Segoe UI Semibold", 10F),
                AutoSize = false,
                Size = new Size(104, 48),
                Location = new Point(16, 0),
                TextAlign = ContentAlignment.MiddleLeft
            };

            Button btnEdit = MakeBarButton("\u270E  Edit", Color.FromArgb(55, 65, 81), 124, 80);
            Button btnDelete = MakeBarButton("\U0001F5D1  Delete", Red, 210, 88);

            selectionBar.Controls.AddRange(new Control[] { lblSelected, btnEdit, btnDelete });
        }

        private static Button MakeBarButton(string text, Color back, int x, int width)
        {
            var b = new Button
            {
                Text = text,
                Size = new Size(width, 32),
                Location = new Point(x, 8),
                FlatStyle = FlatStyle.Flat,
                BackColor = back,
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private void PositionSelectionBar()
        {
            if (selectionBar == null) return;
            selectionBar.Location = new Point(
                (ClientSize.Width - selectionBar.Width) / 2,
                ClientSize.Height - selectionBar.Height - 36);
        }

        private void UpdateSelectionBar()
        {
            int selected = 0;
            foreach (DataGridViewRow row in grid.Rows)
            {
                bool on = Convert.ToBoolean(row.Cells[0].Value);
                if (on) selected++;

                Color tint = on ? Color.FromArgb(239, 246, 255) : Color.White;
                row.DefaultCellStyle.BackColor = tint;
                row.DefaultCellStyle.SelectionBackColor = tint;
            }
            lblSelected.Text = selected + " selected";
            selectionBar.Visible = selected > 0;
        }

        // --------------------------------------------------------- helpers
        private static void AddBorder(Control c)
        {
            c.Paint += (s, e) =>
            {
                using (var pen = new Pen(Border))
                    e.Graphics.DrawRectangle(pen, 0, 0, c.Width - 1, c.Height - 1);
            };
            c.Resize += (s, e) => c.Invalidate();
        }
    }
}