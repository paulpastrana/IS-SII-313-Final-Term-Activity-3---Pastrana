using System;
using System.Drawing;
using System.Windows.Forms;

namespace InventorySystem
{
    public class LoginForm : Form
    {
        private readonly TextBox txtUsername = new TextBox();
        private readonly TextBox txtPassword = new TextBox();
        private readonly CheckBox chkShow = new CheckBox();
        private readonly Button btnLogin = new Button();
        private readonly LinkLabel lnkRegister = new LinkLabel();

        public AppUser LoggedInUser { get; private set; }

        public LoginForm()
        {
            Text = "Inventory System - Login";
            ClientSize = new Size(340, 290);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Font = new Font("Segoe UI", 10F);

            var title = new Label
            {
                Text = "Inventory System",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Bounds = new Rectangle(20, 15, 300, 40)
            };

            var lblUser = new Label { Text = "Username", Location = new Point(30, 70), AutoSize = true };
            txtUsername.Bounds = new Rectangle(30, 94, 280, 27);

            var lblPass = new Label { Text = "Password", Location = new Point(30, 130), AutoSize = true };
            txtPassword.Bounds = new Rectangle(30, 154, 280, 27);
            txtPassword.UseSystemPasswordChar = true;

            chkShow.Text = "Show password";
            chkShow.Location = new Point(30, 187);
            chkShow.AutoSize = true;
            chkShow.CheckedChanged += (s, e) => txtPassword.UseSystemPasswordChar = !chkShow.Checked;

            btnLogin.Text = "Login";
            btnLogin.Bounds = new Rectangle(30, 220, 280, 34);
            btnLogin.Click += BtnLogin_Click;

            lnkRegister.Text = "Don't have an account? Register";
            lnkRegister.AutoSize = false;
            lnkRegister.TextAlign = ContentAlignment.MiddleCenter;
            lnkRegister.Bounds = new Rectangle(30, 258, 280, 24);
            lnkRegister.LinkClicked += LnkRegister_LinkClicked;

            AcceptButton = btnLogin;   // Enter key triggers login
            Controls.AddRange(new Control[] { title, lblUser, txtUsername, lblPass, txtPassword, chkShow, btnLogin, lnkRegister });
        }

        private void LnkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (var reg = new RegisterForm())
            {
                if (reg.ShowDialog(this) == DialogResult.OK)
                {
                    txtUsername.Text = reg.RegisteredUsername;
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
            }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (username.Length == 0 || password.Length == 0)
            {
                MessageBox.Show("Please enter your username and password.", "Login",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                AppUser user = UserRepository.Authenticate(username, password);
                if (user == null)
                {
                    MessageBox.Show("Invalid username or password.", "Login failed",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                    txtPassword.Focus();
                    return;
                }

                LoggedInUser = user;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error:\n\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
