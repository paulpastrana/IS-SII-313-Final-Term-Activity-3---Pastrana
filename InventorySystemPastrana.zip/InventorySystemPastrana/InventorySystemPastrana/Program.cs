using System;
using System.Windows.Forms;

namespace InventorySystem
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                UserRepository.EnsureDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Could not open the database:\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            while (true)
            {
                using (var login = new LoginForm())
                {
                    if (login.ShowDialog() != DialogResult.OK || login.LoggedInUser == null)
                        break;

                    using (var main = new MainForm(login.LoggedInUser))
                    {
                        Application.Run(main);
                        if (!main.LoggedOut) break;   // closed the window = exit app
                    }
                }
            }
        }
    }
}
