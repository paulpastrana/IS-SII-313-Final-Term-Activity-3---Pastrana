using System;
using System.Data.OleDb;
using System.IO;

namespace InventorySystem
{
    public class AppUser
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
    }

    public static class UserRepository
    {
        private static readonly string DbPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Inventory.accdb");

        private const string Provider = "Microsoft.ACE.OLEDB.16.0";

        private static string ConnectionString
        {
            get
            {
                return "Provider=" + Provider + ";Data Source=" + DbPath +
                       ";Persist Security Info=False;";
            }
        }

        /// <summary>Creates the .accdb if missing/invalid, then creates the user table.</summary>
        public static void EnsureDatabase()
        {
            // Remove an empty/corrupt placeholder file
            if (File.Exists(DbPath) && new FileInfo(DbPath).Length < 1024)
                File.Delete(DbPath);

            // Create a real .accdb if none exists (needs the ACE driver, no Access install)
            if (!File.Exists(DbPath))
            {
                Type t = Type.GetTypeFromProgID("ADOX.Catalog");
                dynamic catalog = Activator.CreateInstance(t);
                try
                {
                    catalog.Create("Provider=" + Provider + ";Data Source=" + DbPath);
                }
                finally
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(catalog);
                }
            }

            using (var conn = new OleDbConnection(ConnectionString))
            {
                conn.Open();

                var tables = conn.GetSchema("Tables", new string[] { null, null, "tblUsers", "TABLE" });
                if (tables.Rows.Count > 0) return;

                const string createTable = @"
                    CREATE TABLE tblUsers (
                        UserID COUNTER PRIMARY KEY,
                        Username TEXT(50) NOT NULL,
                        FullName TEXT(100) NOT NULL,
                        PasswordHash TEXT(255) NOT NULL,
                        Salt TEXT(255) NOT NULL,
                        UserRole TEXT(20) NOT NULL,
                        CreatedAt DATETIME
                    )";
                using (var cmd = new OleDbCommand(createTable, conn))
                    cmd.ExecuteNonQuery();

                using (var cmd = new OleDbCommand(
                    "CREATE UNIQUE INDEX idxUsername ON tblUsers (Username)", conn))
                    cmd.ExecuteNonQuery();
            }
        }

        public static bool UsernameExists(string username)
        {
            using (var conn = new OleDbConnection(ConnectionString))
            using (var cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM tblUsers WHERE Username = ?", conn))
            {
                cmd.Parameters.AddWithValue("?", username);
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }

        /// <summary>First account ever registered becomes Admin; everyone else is Staff.</summary>
        public static void Register(string fullName, string username, string password)
        {
            using (var conn = new OleDbConnection(ConnectionString))
            {
                conn.Open();

                int count;
                using (var countCmd = new OleDbCommand("SELECT COUNT(*) FROM tblUsers", conn))
                    count = Convert.ToInt32(countCmd.ExecuteScalar());

                string role = count == 0 ? "Admin" : "Staff";
                string hash, salt;
                PasswordHasher.Hash(password, out hash, out salt);

                using (var cmd = new OleDbCommand(
                    "INSERT INTO tblUsers (Username, FullName, PasswordHash, Salt, UserRole, CreatedAt) " +
                    "VALUES (?, ?, ?, ?, ?, ?)", conn))
                {
                    // OleDb parameters are positional: add them in the same order as the '?' marks
                    cmd.Parameters.AddWithValue("?", username);
                    cmd.Parameters.AddWithValue("?", fullName);
                    cmd.Parameters.AddWithValue("?", hash);
                    cmd.Parameters.AddWithValue("?", salt);
                    cmd.Parameters.AddWithValue("?", role);
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>Returns the user if the credentials are valid, otherwise null.</summary>
        public static AppUser Authenticate(string username, string password)
        {
            using (var conn = new OleDbConnection(ConnectionString))
            using (var cmd = new OleDbCommand(
                "SELECT UserID, Username, FullName, PasswordHash, Salt, UserRole " +
                "FROM tblUsers WHERE Username = ?", conn))
            {
                cmd.Parameters.AddWithValue("?", username);
                conn.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (!reader.Read()) return null;

                    string hash = reader.GetString(3);
                    string salt = reader.GetString(4);
                    if (!PasswordHasher.Verify(password, hash, salt)) return null;

                    return new AppUser
                    {
                        UserId = reader.GetInt32(0),
                        Username = reader.GetString(1),
                        FullName = reader.GetString(2),
                        Role = reader.GetString(5)
                    };
                }
            }
        }
    }
}