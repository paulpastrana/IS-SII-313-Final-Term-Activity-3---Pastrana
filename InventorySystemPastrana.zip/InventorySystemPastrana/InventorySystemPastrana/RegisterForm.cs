using System;
using System.Drawing;
using System.Windows.Forms;

namespace InventorySystem
{
    public class RegisterForm : Form
    {
        private readonly TextBox txtFullName = new TextBox();
        private readonly TextBox txtUsername = new TextBox();
        private readonly TextBox txtPassword = new TextBox();
        private readonly TextBox txtConfirm = new TextBox();
        private readonly Button btnRegister = new Button();
        private readonly Button btnCancel = new Button();

        public string RegisteredUsername { get; private set; }

        public RegisterForm()
        {
            RegisteredUsername = "";

            Text = "Inventory System - Register";
            ClientSize = new Size(340, 390);
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Font = new Font("Segoe UI", 10F);

            var title = new Label
            {
                Text = "Create Account",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Bounds = new Rectangle(20, 15, 300, 40)
            };

            AddField("Full name", txtFullName, 70);
            AddField("Username", txtUsername, 130);
            AddField("Password (min. 8 characters)", txtPassword, 190);
            AddField("Confirm password", txtConfirm, 250);
            txtPassword.UseSystemPasswordChar = true;
            txtConfirm.UseSystemPasswordChar = true;
            txtFullName.MaxLength = 100;
            txtUsername.MaxLength = 50;

            btnRegister.Text = "Register";
            btnRegister.Bounds = new Rectangle(30, 320, 135, 34);
            btnRegister.Click += BtnRegister_Click;

            btnCancel.Text = "Cancel";
            btnCancel.Bounds = new Rectangle(175, 320, 135, 34);
            btnCancel.DialogResult = DialogResult.Cancel;

            AcceptButton = btnRegister;
            CancelButton = btnCancel;
            Controls.AddRange(new Control[] { title, btnRegister, btnCancel });
        }

        private void AddField(string label, TextBox box, int top)
        {
            Controls.Add(new Label { Text = label, Location = new Point(30, top), AutoSize = true });
            box.Bounds = new Rectangle(30, top + 24, 280, 27);
            Controls.Add(box);
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            string error = null;
            if (fullName.Length == 0) error = "Full name is required.";
            else if (username.Length < 3) error = "Username must be at least 3 characters.";
            else if (username.IndexOf(' ') >= 0) error = "Username cannot contain spaces.";
            else if (password.Length < 8) error = "Password must be at least 8 characters.";
            else if (password != txtConfirm.Text) error = "Passwords do not match.";

            if (error != null)
            {
                MessageBox.Show(error, "Register", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (UserRepository.UsernameExists(username))
                {
                    MessageBox.Show("That username is already taken.", "Register",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsername.Focus();
                    return;
                }

                UserRepository.Register(fullName, username, password);
                MessageBox.Show("Account created! You can now log in.", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RegisteredUsername = username;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error:\n\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
